package beans;

public class Magazzino {
	private int idMagazzino;
	private String città;
	private String indirizzo;
	private int idNegozio;
	
	public int getIdMagazzino() {
		return idMagazzino;
	}
	public void setIdMagazzino(int idMagazzino) {
		this.idMagazzino = idMagazzino;
	}
	public String getCittà() {
		return città;
	}
	public void setCittà(String città) {
		this.città = città;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public int getIdNegozio() {
		return idNegozio;
	}
	public void setIdNegozio(int idNegozio) {
		this.idNegozio = idNegozio;
	}
	
	
}
