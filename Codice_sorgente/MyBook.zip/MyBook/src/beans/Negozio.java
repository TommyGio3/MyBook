package beans;

public class Negozio {
	private int idNegozio;
	private String nome;
	private String città;
	private String indirizzo;
	
	public int getIdNegozio() {
		return idNegozio;
	}
	public void setIdNegozio(int idNegozio) {
		this.idNegozio = idNegozio;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCittà() {
		return città;
	}
	public void setCittà(String città) {
		this.città = città;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	
	
}
